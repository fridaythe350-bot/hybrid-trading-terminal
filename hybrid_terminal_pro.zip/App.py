# App.py
# Hybrid Terminal Ultimate Pro+ — TradingView-style Dark Mode
# Main Streamlit app (XAU/USD & BTC/USD) with Smart Candlestick Analyzer
# Place this file in repo root and deploy to Streamlit Cloud.
import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
import pandas_ta as ta
import plotly.graph_objects as go
from io import BytesIO
from datetime import datetime
import json, os, traceback

# Load config (optional)
CFG_FILE = "indicators_config.json"
if os.path.exists(CFG_FILE):
    try:
        with open(CFG_FILE, "r") as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
else:
    cfg = {}

# Page config and load CSS (if exists)
st.set_page_config(page_title="Hybrid Terminal Ultimate Pro+", layout="wide", initial_sidebar_state="expanded")
CSS_FILE = "style.css"
if os.path.exists(CSS_FILE):
    with open(CSS_FILE) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
else:
    st.markdown("<style>body{background:#0b1220;color:#e6eef8}</style>", unsafe_allow_html=True)

# Helpers
@st.cache_data(ttl=300)
def download_symbol(symbol, period="2y", interval="1d"):
    try:
        df = yf.download(symbol, period=period, interval=interval, progress=False)
        if df is None or df.empty:
            return pd.DataFrame()
        df = df.reset_index()
        df.columns = [str(c) for c in df.columns]
        return df
    except Exception:
        return pd.DataFrame()

def compute_indicators(df):
    df = df.copy()
    for c in ["Open","High","Low","Close","Volume"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df["EMA20"] = ta.ema(df["Close"], length=20)
    df["EMA50"] = ta.ema(df["Close"], length=50)
    df["RSI14"] = ta.rsi(df["Close"], length=14)
    macd = ta.macd(df["Close"])
    df["MACD"] = macd.get("MACD_12_26_9"); df["MACD_SIGNAL"] = macd.get("MACDs_12_26_9")
    df["ATR14"] = ta.atr(df["High"], df["Low"], df["Close"], length=14)
    bb = ta.bbands(df["Close"], length=20, std=2)
    df["BBU"] = bb.get("BBU_20_2.0"); df["BBL"] = bb.get("BBL_20_2.0")
    try:
        df["TP"] = (df["High"] + df["Low"] + df["Close"]) / 3
        df["VWAP"] = (df["TP"] * df["Volume"]).cumsum() / (df["Volume"].cumsum())
    except Exception:
        df["VWAP"] = np.nan
    return df

def detect_patterns(df):
    df = df.copy().reset_index(drop=True)
    patterns = []; strengths = []; reasons = []
    for i in range(len(df)):
        p=[]; s=0.0; r=[]
        try:
            o,h,l,c = df.loc[i,["Open","High","Low","Close"]]
            body = abs(c-o); total=(h-l) if (h-l)!=0 else 1e-9
            upper = h - max(o,c); lower = min(o,c) - l
            if body < total*0.06:
                p.append("Doji"); s+=0.3; r.append("Small body: indecision")
            if c>o and body>total*0.6:
                p.append("Bullish Marubozu"); s+=1.2; r.append("Strong bullish body")
            if o>c and body>total*0.6:
                p.append("Bearish Marubozu"); s-=1.2; r.append("Strong bearish body")
            if c>o and lower>body*2:
                p.append("Hammer"); s+=0.9; r.append("Long lower wick - reversal")
            if o>c and upper>body*2:
                p.append("Shooting Star"); s-=0.9; r.append("Upper wick rejection")
            if i>0:
                o1,c1 = df.loc[i-1,["Open","Close"]]
                if c>o and c1<o1 and c>o1 and o<c1:
                    p.append("Bullish Engulfing"); s+=1.3; r.append("Engulfing bullish")
                if o>c and o1<c1 and o>c1 and c<o1:
                    p.append("Bearish Engulfing"); s-=1.3; r.append("Engulfing bearish")
            # context modifiers
            try:
                ema20 = df.loc[i,"EMA20"]; ema50 = df.loc[i,"EMA50"]
                rsi = df.loc[i,"RSI14"]; atr = df.loc[i,"ATR14"]; vol = df.loc[i,"Volume"]
                avgv = df["Volume"].rolling(20).mean().iloc[i] if "Volume" in df.columns else np.nan
                if not np.isnan(ema20) and not np.isnan(ema50):
                    if ema20>ema50: s+=0.3; r.append("Trend bullish (EMA20>EMA50)")
                    else: s-=0.3; r.append("Trend bearish (EMA20<EMA50)")
                if not np.isnan(avgv) and not np.isnan(vol) and vol>avgv*1.5:
                    s+=0.6; r.append("Volume spike")
                if not np.isnan(rsi):
                    if rsi<30: s+=0.4; r.append("RSI oversold")
                    if rsi>70: s-=0.4; r.append("RSI overbought")
            except Exception:
                pass
        except Exception as e:
            p.append("Error"); r.append(str(e))
        patterns.append(", ".join(p) if p else "No Pattern")
        strengths.append(float(np.clip(s,-5,5)))
        reasons.append("; ".join(r))
    df["Pattern"] = patterns; df["Pattern_Strength"]=strengths; df["Pattern_Reason"]=reasons
    return df

def plan_entry(row, sl_mult=1.2):
    try:
        price = float(row["Close"]); atr = float(row["ATR14"])
        sl = price - atr*sl_mult; tp1 = price + atr*1.5*sl_mult
        return {"entry":round(price,4),"sl":round(sl,4),"tp1":round(tp1,4)}
    except Exception:
        return {}

def df_to_xlsx_bytes(df):
    out = BytesIO()
    with pd.ExcelWriter(out, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="analysis")
    return out.getvalue()

# Sidebar
st.sidebar.title("Hybrid Terminal Ultimate Pro+")
asset = st.sidebar.selectbox("Asset", ["XAU/USD (gold)","BTC/USD"], index=0)
symbol = "XAUUSD=X" if asset.startswith("XAU") else "BTC-USD"
interval = st.sidebar.selectbox("Interval", ["1d","1h"], index=0)
period = st.sidebar.selectbox("History", ["2y","5y","max"], index=0)
min_strength = st.sidebar.slider("Min pattern strength to highlight", 0.0, 5.0, 1.0, 0.1)
st.sidebar.markdown("---")
st.sidebar.markdown("Manual Event (optional)")
ev_name = st.sidebar.text_input("Event name (e.g. NFP)")
ev_forecast = st.sidebar.text_input("Forecast (opt)")
ev_actual = st.sidebar.text_input("Actual (opt)")
ev_impact = st.sidebar.selectbox("Impact", ["None","Low","Medium","High"])

if st.sidebar.button("Load & Analyze"):
    try:
        df = download_symbol(symbol, period=period, interval=interval)
        if df.empty:
            st.error("No data returned. Try different interval or upload CSV.")
            st.stop()
        df = compute_indicators(df)
        df = detect_patterns(df)
        # label mapping
        labels=[]
        for i in range(len(df)):
            s = df.loc[i,"Pattern_Strength"]
            if s>=1.5: labels.append("STRONG BUY")
            elif s>=0.6: labels.append("BUY")
            elif s<=-1.5: labels.append("STRONG SELL")
            elif s<=-0.6: labels.append("SELL")
            else: labels.append("WAIT")
        df["Hybrid_Label"]=labels
        st.session_state["df"]=df
        st.success(f"Loaded {len(df)} rows for {symbol}")
    except Exception:
        st.error("Error during analysis. See logs.")
        st.text(traceback.format_exc())

# Main layout
col_chart, col_side = st.columns([3,1])
if "df" in st.session_state:
    df = st.session_state["df"]
    with col_chart:
        st.markdown(f"### 📈 {asset} - Candlestick & Patterns ({interval})")
        n = 400 if interval=="1d" else 160
        view = df.tail(n)
        fig = go.Figure()
        fig.add_trace(go.Candlestick(x=view["Date"], open=view["Open"], high=view["High"], low=view["Low"], close=view["Close"], name="price",
                                    increasing_line_color="#00b894", decreasing_line_color="#ff7675"))
        if "EMA20" in view.columns:
            fig.add_trace(go.Scatter(x=view["Date"], y=view["EMA20"], name="EMA20", line=dict(color="#00d1ff",width=1)))
        if "EMA50" in view.columns:
            fig.add_trace(go.Scatter(x=view["Date"], y=view["EMA50"], name="EMA50", line=dict(color="#ff9f43",width=1)))
        # annotate patterns
        highlights = view[view["Pattern"]!="No Pattern"]
        for idx,row in highlights.iterrows():
            y = row["High"]*1.002 if row["Pattern_Strength"]>0 else row["Low"]*0.998
            marker = "▲" if row["Pattern_Strength"]>0 else "▼"
            fig.add_annotation(x=row["Date"], y=y, text=marker, showarrow=False, font=dict(color="#ffd166",size=12))
        fig.update_layout(template="plotly_dark", height=700, xaxis_rangeslider_visible=False)
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("### 🔍 Recent Patterns & Insight")
        recent = df.tail(12)[["Date","Close","Pattern","Pattern_Strength","Pattern_Reason","Hybrid_Label"]].fillna("")
        st.dataframe(recent.style.format({"Pattern_Strength":"{:.2f}"}), height=300)
        last = df.tail(1).iloc[0]
        st.markdown("### 🔔 Latest Insight")
        if last["Pattern"]!="No Pattern" and abs(last["Pattern_Strength"])>=min_strength:
            bias = "Bullish" if last["Pattern_Strength"]>0 else "Bearish"
            action = ("Buy on confirmation above candle high" if last["Pattern_Strength"]>0 else "Sell on confirmation below candle low")
            if ev_impact=="High":
                action += " — high impact event; prefer smaller size or wait 30m"
            plan = plan_entry(last)
            st.write(f"Pattern: {last['Pattern']} ({bias}, strength {last['Pattern_Strength']:.2f})")
            st.write(f"Context: {last['Pattern_Reason']}")
            st.write("Suggested action: "+action)
            if plan:
                st.write("Entry planner (ATR):", plan)
        else:
            st.write("No strong pattern on latest candle. Wait for confirmation.")
    with col_side:
        st.markdown("### ⚙️ Quick Summary")
        last = df.tail(1).iloc[0]
        st.metric("Last Price", f"{last['Close']:.4f}")
        st.metric("Label", last["Hybrid_Label"])
        st.markdown("**Pattern:** "+(last["Pattern"] if last["Pattern"] else "No Pattern"))
        st.markdown("**Strength:** "+(f"{last['Pattern_Strength']:.2f}" if not pd.isna(last['Pattern_Strength']) else "NA"))
        st.markdown("---")
        st.markdown("### 📊 Pattern Stats (sample)")
        try:
            sample = df[df["Pattern"]!="No Pattern"].groupby("Pattern").size().sort_values(ascending=False).reset_index()
            sample.columns=["Pattern","Count"]
            st.dataframe(sample.head(10))
        except Exception:
            st.write("No stats available")
        st.markdown("---")
        if st.button("Export analysis (Excel)"):
            x = df_to_xlsx_bytes(df)
            st.download_button("Download .xlsx", x, file_name=f"analysis_{symbol}_{datetime.utcnow().date()}.xlsx")
else:
    st.markdown("# Hybrid Terminal Ultimate Pro+\n\nSelect asset & interval, then click **Load & Analyze** to begin.")
st.caption("Educational tool — not financial advice.")
