# 💎 HYBRID TERMINAL ULTIMATE PRO+

> Smart TradingView-style Web Terminal for XAU/USD & BTC/USD  
> Built by Tiara × GPT-5

## Overview
Hybrid Terminal Ultimate Pro+ is a Streamlit-based trading dashboard featuring:
- Smart Candlestick Analyzer (pattern detection + context)
- EMA/RSI/MACD/ATR/BB indicators
- ATR-based entry planner
- Pattern strength scoring and heuristic stats
- Export to Excel
- Dark TradingView-like UI

## Deploy
1. Push this repo to GitHub (public).
2. On Streamlit Cloud (https://share.streamlit.io) click **New app** and choose this repo.
3. Set main file path to `App.py` and deploy.

## Files
- `App.py` — main Streamlit app
- `requirements.txt` — dependencies
- `style.css` — optional custom CSS for dark theme
- `indicators_config.json` — default indicator settings (editable)
- `README.md` — this file

## Notes
- This is an educational tool. Not investment advice.
